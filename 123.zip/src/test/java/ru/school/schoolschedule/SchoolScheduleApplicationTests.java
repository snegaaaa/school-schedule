package ru.school.schoolschedule;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SchoolScheduleApplicationTests {

	@Test
	void contextLoads() {
	}

}
